package com.example.pablo.spaceinvaders.Mock;

/**
 * Created by carlos on 20/04/17.
 */

public class MainActivityMock {

    public boolean isUserInApplication;
    public boolean isUserInMainActivity;
    public boolean isChangeSkinButtonPressed;
    public boolean isLeftPartTapped;
    public boolean isRightPartTapped;
    public boolean isCentralPartTapped;
    public String skinMenu = new String("cambia la skin");

    public MainActivityMock() {
        this.isUserInApplication = true;
        this.isUserInMainActivity = true;
        this.isChangeSkinButtonPressed = false;
        this.isLeftPartTapped = false;
        this.isRightPartTapped = false;
        this.isCentralPartTapped = false;
    }

    public String clickOption() {
        this.isChangeSkinButtonPressed = true;
        return "Tapped successfully";
    }

    public String tapLeft(){
        this.isLeftPartTapped = true;
        return "left tap done";
    }

    public String tapRight(){
        this.isRightPartTapped = true;
        return "right tap done";
    }

    public String tapCentral(){
        this.isCentralPartTapped = true;
        return "central tap done";
    }
    @Override
    public String toString() {
        return skinMenu;
    }

}
