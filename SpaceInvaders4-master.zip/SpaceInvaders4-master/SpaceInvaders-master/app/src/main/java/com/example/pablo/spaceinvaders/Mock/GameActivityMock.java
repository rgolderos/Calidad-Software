package com.example.pablo.spaceinvaders.Mock;

/**
 * Created by carlos on 20/04/17.
 */

public class GameActivityMock {

    public boolean isUserInGameActivity;
    public boolean isRScreenTapped, isLScreenTapped, isMScreenTapped, isEnemyEliminated;
    public int alto, ancho;
    public int[] pantalla = {150, 30};
    public int[] municion = {-1};
    public int[] enemigo = {-1};

    public GameActivityMock() {
        this.alto = 150;
        this.ancho = 150;
        this.isUserInGameActivity = true;
        this.isRScreenTapped = false;
        this.isLScreenTapped = false;
    }

    @Override
    public String toString() {
        return "alto: " + this.alto + "\nAlto: " + this.alto + "\nPosicion de la nave: " + this.toString2();
    }

    private String toString2() {
        return this.pantalla[0] + "," + this.pantalla[1];
    }


    public boolean tapRightScreen() {
        this.isRScreenTapped = true;
        return this.isRScreenTapped;
    }

    public String moveShipToRight() {
        this.pantalla[1] = 70;
        return "Nave movida a " + this.toString2();
    }

    public boolean tapLeftScreen() {
        this.isLScreenTapped = true;
        return this.isLScreenTapped;
    }

    public String moveShipToLeft() {
        this.pantalla[1] =70;
        return "Nave movida a " + this.toString2();
    }


    public boolean tapMiddleScreen() {
        this.isMScreenTapped = true;
        return this.isMScreenTapped;
    }

    public String unleash() {
        this.municion[0] = 100;
        return "Nave disparando ";
    }

    public boolean enemyEliminated(){
        this.isEnemyEliminated = true;
        return this.isEnemyEliminated;
    }

    public String eliminated(){
        this.enemigo[0] = 20;
        return "Enemy down";
    }

}
