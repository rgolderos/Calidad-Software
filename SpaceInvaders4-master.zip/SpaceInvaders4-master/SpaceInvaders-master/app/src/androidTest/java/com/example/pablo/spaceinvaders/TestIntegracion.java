package com.example.pablo.spaceinvaders;

/**
 * Created by carlos on 21/04/17.
 */
        import android.content.Intent;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class TestIntegracion {

    public ActivityTestRule<SpaceInvadersActivity> i = new ActivityTestRule<>(SpaceInvadersActivity.class, false);


    @Test
    public void iniciar() {
        Intent startIntent = new Intent();
        i.launchActivity(startIntent);
    }

 }
