package com.example.pablo.spaceinvaders;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        monochrome = true,
        glue = "classpath:com.example.pablo.spaceinvaders",
        features = "classpath:features//Pruebas.feature"
)
public class CucumberTestCase {
}
