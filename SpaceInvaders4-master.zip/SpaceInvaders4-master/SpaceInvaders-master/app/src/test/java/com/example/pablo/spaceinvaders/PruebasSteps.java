package com.example.pablo.spaceinvaders;

/**
 * Created by carlos on 20/04/17.
 */
import com.example.pablo.spaceinvaders.Mock.GameActivityMock;
import com.example.pablo.spaceinvaders.Mock.MainActivityMock;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class PruebasSteps {

    private MainActivityMock mainActivity;
    private GameActivityMock gameActivity;

    @Before
    public void before_test() {
        this.mainActivity = new MainActivityMock();
        this.gameActivity = new GameActivityMock();
    }

    @Given("^main screen in app$")
    public void main_screen_in_app() {
        Boolean valor = this.mainActivity.isUserInMainActivity;
        System.out.println(valor+"\n");
    }

    @When("^i tap at change skin$")
    public void i_tap_at_change_skin() {
        String valor = this.mainActivity.clickOption();
        System.out.println(valor);
    }

    @Then("^the change skin menu opens$")
    public void the_change_skin_menu_opens() {
        String valor = this.mainActivity.toString();
        System.out.println(valor+"\n\n");
    }

    @Given("^game started$")
    public void game_started(){
        boolean value = this.gameActivity.isUserInGameActivity;
        System.out.println(value+"\n");
    }

    @When("^i tap the bottom right screen$")
    public void i_tap_the_bottom_right_screen() {
        Boolean valor = this.gameActivity.tapRightScreen();
        System.out.println(valor);
    }

    @Then("^the ship moves to the right$")
    public void the_ship_moves_to_the_right() {
        String valor = this.gameActivity.moveShipToRight();
        System.out.println(valor+"\n\n");
    }


    @When("^i tap at the bottom left screen$")
    public void i_tap_the_bottom_left_screen() {
        Boolean valor = this.gameActivity.tapLeftScreen();
        System.out.println(valor);
    }

    @Then("^the ship moves to the left$")
    public void the_ship_moves_to_the_left() {
        String valor = this.gameActivity.moveShipToLeft();
        System.out.println(valor+"\n\n");
    }


    @When("^i tap the central part of the screen$")
    public void i_tap_the_central_part_of_the_screen() {
        Boolean valor = this.gameActivity.tapMiddleScreen();
        System.out.println(valor);
    }

    @Then("^the ship shoots$")
    public void the_ship_shoots() {
        String valor = this.gameActivity.unleash();
        System.out.println(valor+"\n\n");
    }


    @When("^the ship shot$")
    public void the_ship_shot() {
        String valor = this.gameActivity.unleash();
        System.out.println(valor);
    }

    @And("^the bullet hits the enemy$")
    public void the_bullet_hits_the_enemy(){
        boolean valor = this.gameActivity.enemyEliminated();
        System.out.println(valor);
    }

    @Then("^the enemy is eliminated$")
    public void the_enemy_is_eliminated(){

        String valor = this.gameActivity.eliminated();
        System.out.println(valor);
    }
}